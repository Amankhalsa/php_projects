<?php class Admin_model extends CI_Model {
    
    public function __construct() {
        $this->load->database();
    }
    
    // get active secret
    public function getAllSecrets() {
        $this->db->select('*');
        $this->db->from('secrets');
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    // edit/update secret
    function edit($data) {
        $this->db->where('slug', $data['slug']);
        $this->db->update('secrets', $data);
    }
    
    // edit/update category
    function editCat($data) {
        $this->db->where('id', $data['id']);
        $this->db->update('category', $data);
    }
    
    // add new category
    public function addCategory() {
        $data = array(
            'nameCat' => ucfirst($this->input->post('name_cat')),
            'slugCat' => strtolower($this->input->post('slug_cat'))
        );
        return $this->db->insert('category', $data);
    }
    
}