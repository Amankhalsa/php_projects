<?php class Secrets_model extends CI_Model {
    
    public function __construct() {
        $this->load->database();
    }
    
    // get active secret
    public function getActiveSecrets($limit=null, $offset=null) {
        $this->db->select('*');
        $this->db->from('secrets');
        $this->db->where('status', 1); // where status is 1 (active)
        $this->db->order_by('id', 'DESC');
        $this->db->limit($limit);
        $this->db->offset($offset);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    // get inactive secrets
    public function getInactiveSecrets() {
        $this->db->select('*');
        $this->db->from('secrets');
        $this->db->where('status', 2); // where status is 2 (inactive)
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    // get last 5 secrets in sidebar
    public function lastSidebarSecrets() {
        $this->db->select('*');
        $this->db->from('secrets');
        $this->db->where('status', 1); // where status is 1 (active)
        $this->db->order_by('id', 'DESC');
        $this->db->limit(5);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    // get count total secret
    public function getTotalSecrets(){
        return $this->db->count_all('secrets');
    }
    
    // get count active secrets
    public function activeSecrets() {
        $this->db->select('id');
        $this->db->from('secrets');
        $this->db->where('status', 1);
        return $this->db->count_all_results();
    }
    
    // get count inactive secrets
    public function inactiveSecrets() {
        $this->db->select('id');
        $this->db->from('secrets');
        $this->db->where('status', 2);
        return $this->db->count_all_results();
    }
    
    // get count total likes
    public function countLikes() {
        $this->db->select('id');
        $this->db->from('secrets_likes');
        return $this->db->count_all_results();
    }
    
    // get single secret
    public function getSecret($slug) {
        $query = $this->db->get_where('secrets', array('slug'=>$slug));
        return $query->row_array();
    }
    
    // ******************************************************
    // ***************** Categories 
    // ******************************************************
    // get categories
    public function getCategories() {
        $query = $this->db->select('*')->from('category')->get();
        return $query->result_array();
    } 
    
    // get count total secrets by category id
    public function activeCatSecrets($id) {
        $this->db->like('id');
        $this->db->from('secrets');
        $this->db->where('category', $id);
        $this->db->where('status', 1);  
        return $this->db->count_all_results();
    } 
    
    // get active secret by category id
    public function getActiveCatSecrets($id, $limit=null, $offset=null) {
        $this->db->select('*');
        $this->db->from('secrets');
        $this->db->where('category', $id);
        $this->db->where('status', 1);
        $this->db->order_by('id', 'DESC');
        $this->db->limit($limit);
        $this->db->offset($offset);
        $query = $this->db->get();
        return $query->result_array();
        
    } 
    
    // get name category
    public function getNameCat($id) {
        $query = $this->db->get_where('category', array('id'=>$id));
        return $query->row_array();
    }
    
    // get current name category in secrets
    public function currCatName($id) {
        $query = $this->db->get_where('category', array('id'=>$id));
        $item = $query->row_array();
        if ($query->num_rows() > 0) {
            return $item['nameCat'];
        } else {
            echo 'Undefined';
        }
    }
    
    // count total secrets into categories
    public function countSecretsByCat($id) {
        $this->db->like('id');
        $this->db->from('secrets');
        $this->db->where('category', $id); 
        return $this->db->count_all_results();
    } 
    
    // get data specific category
    public function getDataCat($id) {
        $query = $this->db->get_where('category', array('id'=>$id));
        return $query->row_array();
    }

    // ********************************************************
    // *********************** Write 
    // ********************************************************

    public function insertSecret() {
        $slug = url_title(random_string('alnum', 6)); // create random slug
        $ip = $this->input->ip_address(); // get ip address
        $data = array(
            'slug' => $slug,
            'ip_address' => $ip,
            'text' => $this->input->post('text', true),
            'age' => $this->security->sanitize_filename($this->input->post('age', true)),
            'gender' => $this->security->sanitize_filename($this->input->post('gender', true)),
            'category' => $this->security->sanitize_filename($this->input->post('category', true)),
            'status' => 2,
            'created' => time(),
        );
        return $this->db->insert('secrets', $data);
    }
    
    // ********************************************************
    // ******************** Search
    // ********************************************************
    
    public function searchSecrets() {
        $match = $this->input->post('search');
        $this->db->from('secrets');
        $this->db->where('status', 1);
        $this->db->like('text', $match);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    // ********************************************************
    // ******************* Comments
    // ********************************************************
    
    // get comments by slug
    public function getCommentsBySlug($slug) {
        $this->db->select('*');
        $this->db->from('comments');
        $this->db->where('slug_secret', $slug);
        $this->db->where('status', 1);
        $this->db->order_by('id', 'DESC');
        $this->db->limit(10);
        $query = $this->db->get();
        return $query->result_array();    
    }
    
    public function insertComment() {
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'comment' => $this->input->post('comment'),
            'ip_address' => $this->input->ip_address(),
            'slug_secret' => $this->input->post('slug_secret'),
            'created' => time(),
            'status' => 1
        );
        return $this->db->insert('comments', $data);
    }
    
    
}