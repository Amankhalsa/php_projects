<div class="panel panel-default hidden-xs">
    <div class="panel-heading">About us</div>
    <div class="panel-body">
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
        <a href="<?php echo base_url().'write';?>" class="btn btn-success hover"><?php echo $this->lang->line('write');?></a>
        <a href="<?php echo base_url().'pages/rules';?>" class="btn btn-info hover">Rules</a>
    </div>
</div>

<div class="panel panel-default hidden-xs">
    <div class="panel-heading">Secrets of the day</div>
    <?php foreach($lastfive as $item): ?>
    <div class="list-group">
        <a href="<?php echo base_url().'secret/'.$item['slug']; ?>" class="list-group-item">
            <h4 class="list-group-item-heading"><?php if($item['gender'] === '1') { echo $this->lang->line('male'); } else { echo $this->lang->line('female'); } ?>, <?php echo $item['age'].' '.$this->lang->line('years');?></h4>
            <p class="list-group-item-text">
                <?php $str = parse_smileys(word_limiter($item['text'], 15, '...'.$this->lang->line('read_more')), base_url().'assets/smile'); 
                echo $str; ?>
            </p>
        </a>
    </div>
    <?php endforeach; ?>
</div>

<div class="panel panel-default hidden-xs">
    <div class="panel-heading">Statistics</div>
    <ul class="list-group">
        <li class="list-group-item">
            <span class="badge"><?php echo $this->secrets_model->getTotalSecrets();?></span> Total Secrets
        </li>
        <li class="list-group-item">
            <span class="badge"><?php echo $this->secrets_model->activeSecrets();?></span> Active Secrets
        </li>
        <li class="list-group-item">
            <span class="badge"><?php echo $this->secrets_model->inactiveSecrets();?></span> Inactive Secrets
        </li>
        <li class="list-group-item">
            <span class="badge"><?php echo $this->secrets_model->countLikes();?></span> Total Likes
        </li>
    </ul>
</div>

<?php $this->load->view('themes/default/banner/360x'); ?>

<p class="text-muted text-center">
    Copyright &copy;2017, tammanager<br />
    <a href="<?php echo base_url().'pages/about';?>">about us</a> &ndash; <a href="<?php echo base_url().'pages/rules';?>">rules</a>
</p>