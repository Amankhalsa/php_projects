<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $title; ?></title>
	<meta name="description" content="<?php echo $desc; ?>"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Loading Bootstrap -->
	<link href="<?php echo base_url().'assets/bootstrap/css/bootstrap.css';?>" rel="stylesheet">

	<!-- Loading Font Awesome Icons -->
	<link href="<?php echo base_url().'assets/css/font-awesome.min.css';?>" rel="stylesheet">

	<!-- Loading Drunken Parrot UI -->
	<link href="<?php echo base_url().'assets/css/drunken-parrot.css';?>" rel="stylesheet">

	<!-- <link rel="shortcut icon" href="images/favicon.ico"> -->

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
	<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
	<![endif]-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.min.js';?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#myModal").modal('show');
        });
    </script>
</head>
    <body>
        
        <div id="myModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title"><?php echo $this->lang->line('yeah');?></h4>
                    </div>
                    <div class="modal-body">
                        <p><?php echo $this->lang->line('success_message');?></p>
                        <?php echo $this->lang->line('success_message_two');?>
                    </div>
                    <div class="modal-footer">
                        <a href="<?php echo base_url();?>" class="btn btn-success"><?php echo $this->lang->line('okay');?></a>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>                                		