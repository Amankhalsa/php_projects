<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $title; ?></title>
	<meta name="description" content="<?php echo $desc; ?>"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Loading Bootstrap -->
	<link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.css" rel="stylesheet">

	<!-- Loading Font Awesome Icons -->
	<link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">

	<!-- Loading Drunken Parrot UI -->
	<link href="<?php echo base_url(); ?>assets/css/drunken-parrot.css" rel="stylesheet">

	<!-- <link rel="shortcut icon" href="images/favicon.ico"> -->

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
	<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
	<![endif]-->
</head>
    
    <nav class="navbar navbar-inverse" role="navigation">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a href="<?php echo base_url(); ?>write" type="button" class="navbar-toggle collapsed btn btn-primary active"><?php echo $this->lang->line('write');?></a>
                <a class="navbar-brand" href="<?php echo base_url(); ?>"><strong><?php echo $this->lang->line('site_title');?></strong></a>
            </div>
            
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <div class="nav navbar-nav col-sm-3 col-md-3">
                    <form class="navbar-form" action="<?php echo base_url().'search'; ?>" method="POST" role="search">
                        <div class="input-group">
                            <input type="text" class="form-control-search" name="search" value="" size="10" placeholder="<?php echo $this->lang->line('search');?>">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                
                <p class="navbar-text navbar-right">
                    <a href="<?php echo base_url(); ?>write" class="btn btn-block btn-primary active"><?php echo $this->lang->line('write');?></a>
                </p>
                
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Categories <span class="fa-chevron-down fa"></span></a>
                        <ul class="dropdown-menu">
                            <div class="arrow top"></div>
                            <?php foreach($categories as $cat): ?>
                            <li><a href="<?php echo base_url().'category/'.$cat['id']; ?>"><?php echo $cat['nameCat']; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    
    <div class="col-sm-12 hidden-lg" style="margin-bottom:15px">
        <div class="btn-group btn-group-justified">
            <a href="<?php echo base_url(); ?>" class="btn btn-inverse">Home</a>
            <div class="btn-group">
                <button type="button" class="btn btn-inverse dropdown-toggle" data-toggle="dropdown">Categories </button>
                <ul class="dropdown-menu" role="menu">
                    <?php foreach($categories as $cat): ?>
                    <li><a href="<?php echo base_url().'category/'.$cat['id']; ?>"><?php echo $cat['nameCat']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <a href="" class="btn btn-inverse">Random</a>
        </div>
    </div>