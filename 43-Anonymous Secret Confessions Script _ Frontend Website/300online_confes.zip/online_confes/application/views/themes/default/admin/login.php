<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Login</title>
        <!-- Bootstrap core CSS-->
        <link href="<?php echo base_url().'assets/admin/vendor/bootstrap/css/bootstrap.min.css';?>" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="<?php echo base_url().'vendor/font-awesome/css/font-awesome.min.css';?>" rel="stylesheet" type="text/css">
        <!-- Custom styles for this template-->
        <link href="<?php echo base_url().'assets/admin/css/sb-admin.css';?>" rel="stylesheet">
    </head>
    <body class="bg-dark">
        <div class="container" style="margin-top:150px">
            <div class="card card-login mx-auto mt-5">
                <div class="card-header">Login</div>
                <div class="card-body">
                    <?php echo $this->session->flashdata('message'); ?>
                    <?php echo form_open('admin/login'); ?>
                    <div class="form-group">
                        <input class="form-control" type="email" name="identity" value="<?php echo set_value('identity'); ?>" id="identity" placeholder="Email">
                        <?php echo form_error('identity', '<div class="ui pointing red basic label">','</div>'); ?>
                    </div>
                    
                    <div class="form-group">
                        <input type="password" class="form-control" name="password" value="<?php echo set_value('password'); ?>" id="password" placeholder="******">
                        <?php echo form_error('password', '<div class="ui pointing red basic label">','</div>'); ?>
                    </div>
                    
                    <div class="form-group">
                        <div class="form-check">
                            <input type="checkbox" name="remember" value="1" id="remember">
                            <label class="form-check-label">Remember me?</label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-success">Login</button>
                    <?php echo form_close();?>
                </div>
            </div>
        </div>
        
    </body>
</html>