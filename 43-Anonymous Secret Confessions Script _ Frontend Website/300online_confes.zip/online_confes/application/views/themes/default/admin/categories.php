<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Categories - Administration</title>
        <!-- Bootstrap core CSS-->

        <link href="<?php echo base_url().'assets/admin/vendor/bootstrap/css/bootstrap.min.css';?>" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="<?php echo base_url().'assets/admin/vendor/font-awesome/css/font-awesome.min.css';?>" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url().'assets/admin/vendor/datatables/dataTables.bootstrap4.css';?>" rel="stylesheet">
        <link href="https://cdn.datatables.net/responsive/2.1.0/css/responsive.dataTables.css" rel="stylesheet">
        <link href="<?php echo base_url().'assets/admin/css/sb-admin.css'; ?>" rel="stylesheet">
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
            <a class="navbar-brand" href="<?php echo base_url().'admin';?>">Administration</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
                    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
                        <a class="nav-link" href="<?php echo base_url().'admin';?>"><i class="fa fa-fw fa-dashboard"></i><span class="nav-link-text"> Dashboard</span></a>
                    </li>
                    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="My Account">
                        <a class="nav-link" href="<?php echo base_url().'admin/account';?>"><i class="fa fa-fw fa-user-o"></i><span class="nav-link-text"> My account</span></a>
                    </li>
                    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Example Pages">
                        <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseExamplePages" data-parent="#exampleAccordion"><i class="fa fa-fw fa-list"></i><span class="nav-link-text"> Categories</span></a>
                        <ul class="sidenav-second-level collapse" id="collapseExamplePages">
                            <li><a href="<?php echo base_url().'admin/categories';?>">Categories</a></li>
                            <li><a href="<?php echo base_url().'admin/add_category';?>">Add Category</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="navbar-nav sidenav-toggler">
                    <li class="nav-item">
                        <a class="nav-link text-center" id="sidenavToggler"><i class="fa fa-fw fa-angle-left"></i></a>
                    </li>
                </ul>
                
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="<?php echo base_url().'admin/logout'; ?>" class="nav-link">
                            <i class="fa fa-fw fa-sign-out"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </nav>
        
        <div class="content-wrapper">
            <div class="container-fluid">
                <!-- Icon Cards-->
                <div class="row">
                    
                    <div class="col-lg-12"><?php echo $this->session->flashdata('message'); ?></div>
                    
                    <table class="table table-bordered" id="secrets" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Count</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Count</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php foreach($categories as $item): ?>
                            <tr>
                                <td><?php echo $item['id']; ?></td>
                                <td><?php echo $item['nameCat']; ?></td>
                                <td><?php echo $item['slugCat'];?></td>
                                <td><?php echo $this->secrets_model->countSecretsByCat($item['id']); ?></td>
                                <td><div class="btn-group" role="group" aria-label="...">
                                    <a href="<?php echo base_url().'admin/editCat/'.$item['id'];?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                    <a href="<?php echo base_url().'admin/deleteCat/'.$item['id'];?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"><i class="fa fa-trash" aria-hidden="true"></i> Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>  
                </div>
            </div>
            <!-- /.container-fluid-->
            <!-- /.content-wrapper-->
            <footer class="sticky-footer">
                <div class="container">
                    <div class="text-center">
                        <small>Copyright &copy;2017, tammanager</small>
                    </div>
                </div>
            </footer>
            
            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fa fa-angle-up"></i>
            </a>
            
            <!-- Bootstrap core JavaScript-->
            <script src="<?php echo base_url();?>assets/admin/vendor/jquery/jquery.min.js"></script>
            <script src="<?php echo base_url();?>assets/admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
            <!-- Custom scripts for all pages-->
            <script src="<?php echo base_url();?>assets/admin/vendor/datatables/jquery.dataTables.js"></script>
            <script src="<?php echo base_url();?>assets/admin/vendor/datatables/dataTables.bootstrap4.js"></script>
            <script src="<?php echo base_url();?>assets/admin/js/sb-admin.min.js"></script>
            <script src="//cdn.datatables.net/responsive/2.2.0/js/dataTables.responsive.js"></script>
            <script type="text/javascript">
                $(document).ready(function() {
                    $('#secrets').DataTable({
                        "aaSorting": [[0,"desc"]],
                        responsive: true
                    });
                });
            </script>
        </div>
    </body>
</html>