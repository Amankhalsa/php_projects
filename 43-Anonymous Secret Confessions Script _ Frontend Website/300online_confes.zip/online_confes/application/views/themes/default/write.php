<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-10 col-md-8 col-sm-offset-1 col-md-offset-2">
            <?php echo validation_errors('<div class="alert alert-dismissible alert-danger">', '</div>'); 
            echo form_open('write'); ?>
            <h2><?php echo $this->lang->line('writeHeaderOne');?> <small><?php echo $this->lang->line('writeHeaderTwo');?></small></h2>

            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <?php
                    $options = array(
                        '14'        => '14 '.$this->lang->line('years'),
                        '15'        => '15 '.$this->lang->line('years'),
                        '16'        => '16 '.$this->lang->line('years'),
                        '17'        => '17 '.$this->lang->line('years'),
                        '18'        => '18 '.$this->lang->line('years'),
                        '19'        => '19 '.$this->lang->line('years'),
                        '20'        => '20 '.$this->lang->line('years'),
                        '21'        => '21 '.$this->lang->line('years'),
                        '22'        => '22 '.$this->lang->line('years'),
                        '23'        => '23 '.$this->lang->line('years'),
                        '24'        => '24 '.$this->lang->line('years'),
                        '25'        => '25 '.$this->lang->line('years'),
                        '26'        => '26 '.$this->lang->line('years'),
                        '27'        => '27 '.$this->lang->line('years'),
                        '28'        => '28 '.$this->lang->line('years'),
                        '29'        => '29 '.$this->lang->line('years'),
                        '30'        => '30 '.$this->lang->line('years'),
                        '31'        => '31 '.$this->lang->line('years'),
                        '32'        => '32 '.$this->lang->line('years'),
                        '33'        => '33 '.$this->lang->line('years'),
                        '34'        => '34 '.$this->lang->line('years'),
                        '35'        => '35 '.$this->lang->line('years'),
                        '36'        => '36 '.$this->lang->line('years'),
                        '37'        => '37 '.$this->lang->line('years'),
                        '38'        => '38 '.$this->lang->line('years'),
                        '39'        => '39 '.$this->lang->line('years'),
                        '40'        => '40 '.$this->lang->line('years'),
                        '41'        => '41 '.$this->lang->line('years'),
                        '42'        => '42 '.$this->lang->line('years'),
                        '43'        => '43 '.$this->lang->line('years'),
                        '44'        => '44 '.$this->lang->line('years'),
                        '45'        => '45 '.$this->lang->line('years'),
                        '46'        => '46 '.$this->lang->line('years'),
                        '47'        => '47 '.$this->lang->line('years'),
                        '48'        => '48 '.$this->lang->line('years'),
                        '49'        => '49 '.$this->lang->line('years'),
                        '50'        => '50 '.$this->lang->line('years'),
                        '51'        => '51 '.$this->lang->line('years'),
                    );
                    echo form_dropdown('age', $options, '18', 'class="form-control input-lg"'); ?>
                </div>
                
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <div class="form-group">
                        <select class="form-control input-lg" name="gender">
                            <option value="1"><?php echo $this->lang->line('male');?></option>
                            <option value="2"><?php echo $this->lang->line('female');?></option>
                            <option value="3"><?php echo $this->lang->line('not-binary');?></option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <?php echo $smile; ?>
                <textarea type="textarea" name="text" id="text" class="form-control" rows="8" placeholder="<?php echo $this->lang->line('writeSecret');?>"><?php echo set_value('text'); ?></textarea>
                <?php echo form_error('text', '<span class="label label-danger">', '</span>'); ?>
            </div>
            <div class="form-group">
                <div class="form-group">
                    <select class="form-control input-lg" name="category">
                        <?php foreach($categories as $cat): ?>
                        <option value="<?php echo $cat['id'];?>"><?php echo $cat['nameCat'];?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <input type="submit" class="btn btn-kr btn-block btn-primary active" value="<?php echo $this->lang->line('send');?>" />
                </div>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>