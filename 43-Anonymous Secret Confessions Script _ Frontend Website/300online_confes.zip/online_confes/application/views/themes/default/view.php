<div class="container"> 
        <div class="row"> 
            <div class="col-lg-8">
                <?php if($item['gender'] === '1') { ?><div class="panel panel-primary"><?php } elseif($item['gender'] === '2') { ?><div class="panel panel-info"><?php } else { ?><div class="panel panel-warning"><?php } ?>
                    <div class="panel-heading">
                        <h3 class="panel-title"><a href="<?php echo base_url();?>secret/<?php echo $item['slug'];?>"><?php if($item['gender'] === '1') { echo $this->lang->line('male'); } elseif($item['gender'] === '2') { echo $this->lang->line('female'); } else { echo $this->lang->line('not-binary'); } ?>, <?php echo $item['age'].' '.$this->lang->line('years');?></a></h3>
                    </div>
                    <div class="panel-body">
                        <?php $str = parse_smileys($item['text'], base_url().'assets/smile');
                        echo $str; ?>
                        <p class="text-muted"><small><?php echo $this->secrets_model->currCatName($item['category']);?> - <?php 
                        $post_date = $item['created'];
                        $now = time();
                        echo timespan($post_date, $now, 1).' '.$this->lang->line('ago'); ?>
                        </small></p>
                        <hr>
                        <!-- button like -->
                        <a onclick="javascript:savelike(<?php echo $item['id']; ?>);" style="cursor:pointer;" class="btn btn-xs btn-primary active">
                            <span id="like_<?php echo $item['id']; ?>">
                                <?php if($item['likes']>0){echo $item['likes'].' Likes';}else{echo 'I Like';} ?>
                            </span>
                        </a>  
                        <span class="pull-right">
                            <div class="btn-group btn-group-dropdown">
                                <a href="" class="btn btn-xs btn-info" data-toggle="dropdown"><i class="fa fa-share-alt" aria-hidden="true"></i></a>
								<ul class="dropdown-menu dropdown-menu-right" role="menu">
									<div class="arrow top"></div>
									<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url(); ?>secret/<?php echo $item['slug']; ?>" target="_blank">Facebook</a></li>
									<li><a href="whatsapp://send?text=<?php echo base_url(); ?>secret/<?php echo $item['slug']; ?>" target="_blank">WhatsApp</a></li>
									<li><a href="https://plus.google.com/share?url=<?php echo base_url(); ?>secret/<?php echo $item['slug']; ?>" target="_blank">Google</a></li>
                                    <li><a href="https://twitter.com/intent/tweet?text=<?php echo word_limiter($item['text'], 9); ?> - <?php echo base_url().'secret/'.$item['slug']; ?>" target="_blank">Twitter</a></li>
								</ul>
							</div>
                        </span>
                    </div>
                </div>
                
                <h2 id="#comments">Comments</h2>
                <!-- comments widget -->
                
                <?php foreach($comments as $comm): ?>
                <div class="panel panel-default">
                    <div class="panel-heading"><strong><?php echo $comm['name']; ?></strong> says:</div>
                    <div class="panel-body">
                        <p><?php echo $comm['comment']; ?></p>
                        <small><?php $post_date = $comm['created']; $now = time();
                        echo timespan($post_date, $now, 1).' '.$this->lang->line('ago'); ?>
                        </small>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <div class="panel panel-default" style="margin-top:20px">
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="">
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Name</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo set_value('name'); ?>">
                                    <?php echo form_error('name', '<span class="label label-danger">', '</span>'); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Email</label>
                                <div class="col-sm-9">
                                    <input type="email" class="form-control" name="email" value="<?php echo set_value('email'); ?>" placeholder="Email">
                                    <?php echo form_error('email', '<span class="label label-danger">', '</span>'); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Comment</label>
                                <div class="col-sm-9">
                                    <textarea type="textarea" class="form-control" name="comment"><?php echo set_value('comment'); ?></textarea>
                                    <?php echo form_error('comment', '<span class="label label-danger">', '</span>'); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <input type="hidden" name="slug_secret" value="<?php echo $item['slug']; ?>">
                                    <input type="submit" class="btn btn-primary btn-lg pull-right" value="Add Comment"/>
                                </div>
                            </div>
                        </form>
                        

                    </div>
                </div> <!-- /comments -->
                
            </div>
            <div class="col-lg-4">
                <?php $this->load->view('themes/default/sidebar'); ?>
            </div>
         </div>
    </div>
    
<script type="text/javascript">
    function savelike(secrets_id) {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('Secrets/savelikes');?>",
            data: "secrets_id="+secrets_id,
            success: function (response) {
                $("#like_"+secrets_id).html(response+" Likes");
            }
        });
    }
</script>