<div class="container"> 
        <div class="row"> 
            <div class="col-lg-8">
                <?php foreach($secrets as $item): ?>
                <?php if($item['gender'] === '1') { ?><div class="panel panel-primary"><?php } elseif($item['gender'] === '2') { ?><div class="panel panel-info"><?php } else { ?><div class="panel panel-warning"><?php } ?>
                    <div class="panel-heading">
                        <h3 class="panel-title"><a href="<?php echo base_url();?>secret/<?php echo $item['slug'];?>"><?php if($item['gender'] === '1') { echo $this->lang->line('male'); } elseif($item['gender'] === '2') { echo $this->lang->line('female'); } else { echo $this->lang->line('not-binary'); } ?>, <?php echo $item['age'].' '.$this->lang->line('years');?></a></h3>
                    </div>
                    <div class="panel-body">
                        <?php $str = parse_smileys($item['text'], base_url().'assets/smile');
                        echo $str; ?>
                        <p class="text-muted"><small><?php echo $this->secrets_model->currCatName($item['category']);?> - <?php 
                        $post_date = $item['created'];
                        $now = time();
                        echo timespan($post_date, $now, 1).' '.$this->lang->line('ago'); ?>
                        </small></p>
                        <hr>
                        
                        <!-- button like -->
                        <a onclick="javascript:savelike(<?php echo $item['id']; ?>);" style="cursor:pointer;" class="btn btn-xs btn-primary active">
                            <span id="like_<?php echo $item['id']; ?>">
                                <?php if($item['likes']>0){echo $item['likes'].' Likes';}else{echo 'I Like';} ?>
                            </span>
                        </a>  
                        
                        <span class="pull-right">
                            <a href="<?php echo base_url().'secret/'.$item['slug'];?>" class="btn btn-xs btn-info">Comments</a>
                            <div class="btn-group btn-group-dropdown">
                                <a href="" class="btn btn-xs btn-info" data-toggle="dropdown"><i class="fa fa-share-alt" aria-hidden="true"></i></a>
								<ul class="dropdown-menu dropdown-menu-right" role="menu">
									<div class="arrow top"></div>
									<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url(); ?>secret/<?php echo $item['slug']; ?>" target="_blank">Facebook</a></li>
									<li><a href="whatsapp://send?text=<?php echo base_url(); ?>secret/<?php echo $item['slug']; ?>" target="_blank">WhatsApp</a></li>
									<li><a href="https://plus.google.com/share?url=<?php echo base_url(); ?>secret/<?php echo $item['slug']; ?>" target="_blank">Google</a></li>
                                    <li><a href="https://twitter.com/intent/tweet?text=<?php echo word_limiter($item['text'], 9); ?> - <?php echo base_url().'secret/'.$item['slug']; ?>" target="_blank">Twitter</a></li>
								</ul>
							</div>
                        </span>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php echo $this->pagination->create_links(); ?>
                
            </div>
            <div class="col-lg-4">
                <?php $this->load->view('themes/default/sidebar'); ?>
            </div>
         </div>
    </div>
    
<script type="text/javascript">
    function savelike(secrets_id) {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('Secrets/savelikes');?>",
            data: "secrets_id="+secrets_id,
            success: function (response) {
                $("#like_"+secrets_id).html(response+" Likes");
            }
        });
    }
</script>