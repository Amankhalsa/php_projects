<div class="container">
    <div class="row">
        <div class="col-lg-12 pull-center text-center">
            <img src="<?php echo base_url();?>assets/images/error-404.png" alt="">
        </div>
    </div>
</div>