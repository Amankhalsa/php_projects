<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Not_found extends CI_Controller {
    
    public function __construct() {
        parent::__construct(); 
    } 

    public function index() { 
        $data['categories'] = $this->secrets_model->getCategories(); // get categories
        
        $data['title'] = '404';
        $data['desc'] = 'Description...';
        
        $this->load->view('themes/default/header', $data);
        $this->load->view('errors/html/error_404');
        $this->load->view('themes/default/footer');
    } 
    
} 