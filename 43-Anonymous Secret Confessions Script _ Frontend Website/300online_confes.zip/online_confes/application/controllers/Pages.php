<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
    
    public function __construct() {
        parent::__construct(); 
    } 

    public function about() { 
        
        $data['categories'] = $this->secrets_model->getCategories(); // get categories
        $data['lastfive'] = $this->secrets_model->lastSidebarSecrets(); // get last 5 secrets
        
        $data['title'] = $this->lang->line('title_about').' - '.$this->lang->line('sitetitle');
        $data['desc'] = $this->lang->line('desc_about');
        
        $this->load->view('themes/default/header', $data);
        $this->load->view('pages/about');
        $this->load->view('themes/default/footer');
        
    } 
    
    public function rules() { 
        
        $data['categories'] = $this->secrets_model->getCategories(); // get categories
        $data['lastfive'] = $this->secrets_model->lastSidebarSecrets(); // get last 5 secrets
        
        $data['title'] = $this->lang->line('title_rules').' - '.$this->lang->line('sitetitle');
        $data['desc'] = $this->lang->line('desc_rules');
        
        $this->load->view('themes/default/header', $data);
        $this->load->view('pages/rules');
        $this->load->view('themes/default/footer');
        
    } 
    
} 