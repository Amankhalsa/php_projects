<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Secrets extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

	public function index($offset = 0) {
        
        $total = 10; // total result x page

        // Config setup
        $num_rows = $this->secrets_model->activeSecrets();
        $config['base_url'] = base_url();
        $config['total_rows'] = $num_rows;
        $config['per_page'] = $total;
        $config['num_links'] = $num_rows;
        $config['use_page_numbers'] = TRUE;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';
        $config['uri_segment'] = 2;
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['next_link'] = '&raquo;';
        
        if ($this->input->get('page') != null) {
            $offset = ($this->input->get('page') - 1) * $config['per_page'];
        }

        $this->pagination->initialize($config);
        
        $data['secrets'] = $this->secrets_model->getActiveSecrets($config['per_page'], $offset);
        $data['categories'] = $this->secrets_model->getCategories(); // get categories
        $data['lastfive'] = $this->secrets_model->lastSidebarSecrets(); // get last 5 secrets

        $data['title'] = $this->lang->line('title_index').' - '.$this->lang->line('sitetitle');
        $data['desc'] = $this->lang->line('desc_index');
        
        $this->load->view('themes/default/header', $data);
        $this->load->view('index', $data);
        $this->load->view('themes/default/footer');
        
	}
    
    // ****************************************************************
    // **************************** Single View
    // ****************************************************************
    
    public function view($slug = NULL) {
        // get single secret
        $data['item'] = $this->secrets_model->getSecret($slug);
        if(empty($data['item'])) {
            show_404();
        }

        $data['categories'] = $this->secrets_model->getCategories(); // get categories
        $data['lastfive'] = $this->secrets_model->lastSidebarSecrets(); // get last 5 secrets
        $data['comments'] = $this->secrets_model->getCommentsBySlug($slug); // get last 5 secrets
        
        $data['title'] = $this->lang->line('sitetitle').' - '.word_limiter($data['item']['text'], 9);
        $data['desc'] = word_limiter($data['item']['text'], 9).$this->lang->line('read_more');
        
        
        // comments
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('comment', 'Comment', 'required|min_length[5]|max_length[250]');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('themes/default/header', $data);
            $this->load->view('secrets/view', $data);
            $this->load->view('themes/default/footer');
        } else {
            $this->secrets_model->insertComment();
            redirect(base_url().'secret/'.$slug);
        }
    }

    // *************************************************************
    // ************************ Write
    // *************************************************************
    
    public function write() {
        
        $this->form_validation->set_rules('age', 'Age', 'required');
        $this->form_validation->set_rules('gender', 'Gender', 'required');
        $this->form_validation->set_rules('text', 'Secret', 'required|min_length[65]|max_length[500]');
        $this->form_validation->set_rules('category', 'Category', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            
            $smile = get_clickable_smileys(base_url().'assets/smile/', 'text');
            $col_array = $this->table->make_columns($smile, 8);
            
            $data['categories'] = $this->secrets_model->getCategories(); // get categories
            $data['smile'] = $this->table->generate($col_array);
            
            $data['title'] = $this->lang->line('title_write').' - '.$this->lang->line('sitetitle');
            $data['desc'] = $this->lang->line('desc_write');
            
            $this->load->view('themes/default/header', $data);
            $this->load->view('secrets/write', $data);
            $this->load->view('themes/default/footer');
            
        } else {
            
            $data['title'] = $this->lang->line('title_success').' - '.$this->lang->line('sitetitle');
            $data['desc'] = $this->lang->line('desc_success');
            
            $this->secrets_model->insertSecret();
            $this->load->view('themes/default/success', $data);
            
        }
    }
    
    // ****************************************************************
    // ************************* Category
    // ****************************************************************
    
    public function category($id=null, $offset=0) {
 
        $total = 10; // total result x page

        // Config setup
        $num_rows = $this->secrets_model->activeCatSecrets($id); // count active secrets in cat
        $config['base_url'] = base_url().'category/'.$id;
        $config['total_rows'] = $num_rows;
        $config['per_page'] = $total;
        $config['num_links'] = $num_rows;
        $config['use_page_numbers'] = TRUE;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['next_link'] = '&raquo;';
        
        if ($this->input->get('page') != null) {
            $offset = ($this->input->get('page') - 1) * $config['per_page'];
        }
        
        $this->pagination->initialize($config);
        
        $data['secrets'] = $this->secrets_model->getActiveCatSecrets($id, $config['per_page'], $offset);
        $data['categories'] = $this->secrets_model->getCategories(); // get categories
        $data['lastfive'] = $this->secrets_model->lastSidebarSecrets(); // get last 5 secrets
        
        $data['nameCat'] = $this->secrets_model->getNameCat($id);
        $data['title'] = $data['nameCat']['nameCat'].' - '.$this->lang->line('sitetitle');
        $data['desc'] = $this->lang->line('desc_index');
            
        $this->load->view('themes/default/header', $data);
        $this->load->view('secrets/category', $data);
        $this->load->view('themes/default/footer');

	}
    
    // ***************************************************************
    // ***************************** Search
    // ***************************************************************
    
    public function search() {
        
        $this->form_validation->set_rules('search', 'Search', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            redirect('');
            exit();
        } else {
            
            $data['query'] = $this->secrets_model->searchSecrets();
            $data['categories'] = $this->secrets_model->getCategories(); // get categories
            $data['lastfive'] = $this->secrets_model->lastSidebarSecrets(); // get last 5 secrets
            
            $data['title'] = $this->input->post('search').' - '.$this->lang->line('sitetitle');
            $data['desc'] = 'Description...';
            
            $this->load->view('themes/default/header', $data);
            $this->load->view('secrets/search', $data);
            $this->load->view('themes/default/footer');  
            
        }
    }
    
    // ***************************************************************
    // ***************************** Likes 
    // ***************************************************************
    
    public function savelikes() {
        
        if (empty($this->input->post('secrets_id'))) {
            redirect('');
        }
        
        $ipaddress = $this->input->ip_address();
        $secrets_id = $this->input->post('secrets_id');
        $secrets_slug = $this->input->post('secrets_slug');
        
        $fetchlikes = $this->db->query('select likes from secrets where id="'.$secrets_id.'"');
        $result = $fetchlikes->result();
        
        $checklikes = $this->db->query('select * from secrets_likes 
                                        where secrets_id="'.$secrets_id.'" 
                                        and ipaddress = "'.$ipaddress.'"');
        $resultchecklikes = $checklikes->num_rows();
        
        if($resultchecklikes == '0' ){
            if($result[0]->likes=="" || $result[0]->likes=="NULL") {
                $this->db->query('update secrets set likes=1 where id="'.$secrets_id.'"');
            } else {
                $this->db->query('update secrets set likes=likes+1 where id="'.$secrets_id.'"');
            }
            
            $data = array(
                'secrets_id' => $secrets_id,
                'ipaddress' => $ipaddress,
                'date' => time(),
            );
            $this->db->insert('secrets_likes', $data);
        } else {
            $this->db->delete('secrets_likes', array('secrets_id'=>$secrets_id,
                                          'ipaddress'=>$ipaddress));
            $this->db->query('update secrets set likes=likes-1 where id="'.$secrets_id.'"');
        }
        
        $this->db->select('likes');
        $this->db->from('secrets');
        $this->db->where('id', $secrets_id);
        $query = $this->db->get();
        $result = $query->result();
        echo $result[0]->likes;
    }
    
}