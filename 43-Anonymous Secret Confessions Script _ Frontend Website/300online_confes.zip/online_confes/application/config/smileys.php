<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| SMILEYS
| -------------------------------------------------------------------
| This file contains an array of smileys for use with the emoticon helper.
| Individual images can be used to replace multiple smileys.  For example:
| :-) and :) use the same image replacement.
|
| Please see user guide for more info:
| https://codeigniter.com/user_guide/helpers/smiley_helper.html
|
*/
$smileys = array(

//	smiley			image name						width	height	alt

	':)'			=>	array('smile.png',			'16',	'16',	'smile'),
	':lol:'			=>	array('lol.png',			'16',	'16',	'LOL'),
	':cheese:'		=>	array('cheese.png',			'16',	'16',	'cheese'),
    ':sad+:'		=>	array('sad+.png',			'16',	'16',	'sad+'),
    ':smug:'		=>	array('smug.png',			'16',	'16',	'smug'),
    ':angry:'		=>	array('angry.png',			'16',	'16',	'angry'),
    ':sad:'		=>	array('sad.png',			'16',	'16',	'sad'),
    ':tired:'		=>	array('tired.png',			'16',	'16',	'tired')
);