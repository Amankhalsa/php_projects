<?php
// *************************************************
// ********************** SEO
// *************************************************
$lang['sitetitle'] = 'Anonymous';
// index title
$lang['title_index'] = 'Tell all your secrets';
$lang['desc_index'] = 'Description...';
// write title
$lang['title_write'] = 'Send a secret';
$lang['desc_write'] = 'Description...';
// success
$lang['title_success'] = 'Success';
$lang['desc_success'] = 'Description...';
// about page
$lang['title_about'] = 'About us';
$lang['desc_about'] = 'Description...';
// rules page
$lang['title_rules'] = 'Rules';
$lang['desc_rules'] = 'Description...';

// *************************************************
// *************** GENERAL LANGUAGES
// *************************************************

// navbar
$lang['site_title'] = 'Anonymous';
$lang['home'] = 'Home';
$lang['write'] = 'Write Secret';
// search
$lang['search'] = 'Search';
// write
$lang['writeHeaderOne'] = 'Your secret';
$lang['writeHeaderTwo'] = 'is safe with us';
$lang['writeSecret'] = 'Write your secret...';
$lang['years'] = 'years';
$lang['male'] = 'Male';
$lang['female'] = 'Female';
$lang['not-binary'] = 'Not-Binary';
$lang['send'] = 'Send';
// secrets
$lang['ago'] = 'ago';
$lang['read_more'] = 'read more';
// success page
$lang['yeah'] = 'Oooh Yeah!!!';
$lang['success_message'] = 'Your secret has been sent!';
$lang['success_message_two'] = 'But first, our moderator will have to check it for all the rules to be respected and then be approved.';
$lang['okay'] = "Okay";