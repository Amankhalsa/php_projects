<?php
defined('BASEPATH') or exit('No direct script access allowed');

echo "\nDatabase error: ",
    $heading,
    "\n\n",
    $message,
    "\n\n";
