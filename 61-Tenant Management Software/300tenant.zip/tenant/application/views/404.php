<div class="content-wrapper">
    <h3>404
        <small>Page Not Found</small>
    </h3>
    <div class="row">
        <div class="col-sm-4 col-sm-offset-4">
            <div class="panel widget">
				<img src="<?php echo base_url(); ?>assets/app/img/404.jpg" alt="Image" class="img-responsive">
			</div>
        </div>
    </div>
</div>

