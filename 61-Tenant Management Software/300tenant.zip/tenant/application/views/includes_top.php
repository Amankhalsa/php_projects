<link rel="stylesheet" href="<?php echo base_url(); ?>assets/app/css/bootstrap.css">
<!-- Vendor CSS-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/fontawesome/css/font-awesome.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/animo/animate+animo.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/csspinner/csspinner.min.css">

<!-- START Page Custom CSS-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/slider/css/slider.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/chosen/chosen.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datetimepicker/css/bootstrap-datetimepicker.min.css">
<!-- Codemirror -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/codemirror/lib/codemirror.css">
<!-- Bootstrap tags-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/tagsinput/bootstrap-tagsinput.css">
<!-- END Page Custom CSS-->

<!-- START Page Custom CSS-->
<!-- Data Table styles-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/DataTables/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/DataTables/css/rowReorder.dataTables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/DataTables/css/responsive.dataTables.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<!-- END Page Custom CSS-->

<!-- App CSS-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/app/css/app.css">
<!-- Modernizr JS Script-->
<script src="<?php echo base_url(); ?>assets/vendor/modernizr/modernizr.js" type="application/javascript"></script>
<!-- FastClick for mobiles-->
<script src="<?php echo base_url(); ?>assets/vendor/fastclick/fastclick.js" type="application/javascript"></script>

<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/app/js/app.js"></script>

<script>
	toastr.options = {
		"closeButton": false,
		"debug": false,
		"newestOnTop": false,
		"progressBar": false,
		"positionClass": "toast-bottom-right",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	}
</script>
