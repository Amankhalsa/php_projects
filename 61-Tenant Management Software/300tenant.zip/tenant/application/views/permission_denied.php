<div class="content-wrapper">
    <h3>Access
        <small>Permission Denied</small>
    </h3>
    <div class="row">
        <div class="col-sm-4 col-sm-offset-4">
            <div class="panel widget">
				<div class="row row-table row-flush">
					<div class="col-xs-5">
					   <picture class="lateral-picture">
						  <img src="<?php echo base_url(); ?>assets/app/img/denied.png" alt="">
					   </picture>
					</div>
					<div class="col-xs-7 align-middle p-lg">
					   <p><strong>No Entry</strong></p>
					   <p>Sorry, You do not have permission to access this page.</p>
					</div>
				</div>
			</div>
        </div>
    </div>
</div>
